---
name: Kinetic Notch
colors:
  surface: '#111319'
  surface-dim: '#111319'
  surface-bright: '#36393f'
  surface-container-lowest: '#0b0e13'
  surface-container-low: '#191c21'
  surface-container: '#1d2025'
  surface-container-high: '#272a30'
  surface-container-highest: '#32353a'
  on-surface: '#e1e2e9'
  on-surface-variant: '#b9cbbd'
  inverse-surface: '#e1e2e9'
  inverse-on-surface: '#2e3036'
  outline: '#849588'
  outline-variant: '#3b4a40'
  surface-tint: '#00e293'
  primary: '#cdffde'
  on-primary: '#003921'
  primary-container: '#00f5a0'
  on-primary-container: '#006b43'
  inverse-primary: '#006c44'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#cbffdf'
  on-tertiary: '#003823'
  tertiary-container: '#43f2a9'
  on-tertiary-container: '#006b45'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#50ffaf'
  primary-fixed-dim: '#00e293'
  on-primary-fixed: '#002111'
  on-primary-fixed-variant: '#005232'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#53feb4'
  tertiary-fixed-dim: '#26e19a'
  on-tertiary-fixed: '#002112'
  on-tertiary-fixed-variant: '#005234'
  background: '#111319'
  on-background: '#e1e2e9'
  surface-variant: '#32353a'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies the ethos of a high-precision, native system-level Android utility. Designed specifically for granular gesture customization around the camera cutout (punch-hole), it conveys silent performance, absolute reliability, and zero computational bloat. The target demographic consists of Android power users, customization enthusiasts, and professionals who demand instant haptic feedback, fluid responsiveness, and purposeful aesthetics without decorative noise.

The visual direction combines **Matte OLED Minimalism** with tactile, hardware-aligned cues reminiscent of advanced Material You and Samsung One UI 6+. The interface uses deep, power-saving obsidian tones layered with soft matte finishes and high-luminance mint accents. It evokes the feeling of a refined operating system extension—akin to an unreleased internal Google Pixel or Sony Xperia diagnostic tool—rather than a third-party ad-ridden launcher.

## Colors

The color palette is engineered for pure OLED efficiency, tactile clarity, and AA/AAA accessibility compliance on high-refresh-rate mobile displays:

- **Primary Canvas & Backgrounds**:
  - Base canvas (`#0E1116`): Ultra-deep charcoal black providing true-black aesthetics without harsh black-smearing artifacts on OLED panels.
  - Surface Container Low (`#161B22`): Recessed module containers and nested gesture interaction zones.
  - Surface Container Medium (`#21262D`): Active cards, toggles, and modal sheets.
  - Surface Container High (`#30363D`): Elevated floating controls and active interaction zones.

- **Vibrant Mint Accents**:
  - Kinetic Mint Primary (`#00F5A0`): High-luminance signal green reserved strictly for active gesture vectors, punch-hole rings, primary toggles, and direct activation states.
  - Emerald Action Secondary (`#10B981`): Sustained tactile elements, confirm buttons, and stable active services.
  - Mint Glow Tertiary (`#2EE59D`): Subtle haptic illumination overlays and gradient highlights.

- **Status & Warning Spectrum**:
  - Permission Missing / Caution: `#F59E0B` (Amber)
  - Accessibility Alert / Conflict: `#EF4444` (Crimson)
  - System Synced / Sensor Active: `#38BDF8` (Sky)

- **Typography & Structural Contrast**:
  - Primary Content: `#F0F6FC` (95% opacity white for optimum legibility against matte obsidian).
  - Secondary Content: `#8B949E` (Subdued neutral for gesture descriptions and metadata).
  - Subtle Borders / Outlines: `rgba(240, 246, 252, 0.08)`.

## Typography

The design system relies exclusively on **Plus Jakarta Sans** across all hierarchies. Its geometric construction, wide apertures, and balanced x-height produce exceptional readability on compact mobile viewports, especially when users interact with one hand.

- **Headlines**: Set tightly with negative letter spacing for punchy, modern tool titles and category hubs (`headline-lg` / `headline-lg-mobile`).
- **Body Text**: Tuned for maximum technical clarity. Descriptions of accessibility services, hardware coordinates, and sensor triggers use `body-md` and `body-sm` with generous line heights to prevent visual fatigue.
- **Labels & Micro-indicators**: Rendered with slightly increased tracking (`label-sm`, `label-md`) and heavier weights (`600` and `700`) to guarantee legibility in compact hardware chip tags, gesture badges (e.g., "SWIPE DOWN", "DOUBLE TAP"), and calibration meters.

## Layout & Spacing

The layout is built for direct single-hand thumb navigation (inspired by One UI's lower-half interaction paradigm) and strict portrait density:

- **Grid Model**: A fluid 4-column layout on standard phones with `gutter: 1rem` (16px) and `margin: 1rem` (16px). For folding screens or wide tablet previews, it expands to 8 columns with `gutter: 1.5rem` and centered safe zones.
- **Punch-Hole Alignment Zone**: A reserved, dynamic top-canvas area dedicated to hardware visualization. Layout margins accommodate Android dynamic notches, center holes, and offset corner sensors without overlapping interactive UI elements.
- **Rhythm**: All spacings scale via multiples of 4px/8px:
  - `space-xs` (4px): Inner badge padding and icon-to-label inline offsets.
  - `space-sm` (8px): Gaps between nested list toggles, pill chips, and status rows.
  - `space-md` (16px): Standard container internal padding and card separation.
  - `space-lg` (24px): Structural category grouping margins.
  - `space-xl` (32px): Separation between main functional sections and floating trigger controls.

## Elevation & Depth

Visual hierarchy is maintained through **Tonal Micro-Surfaces** combined with crisp, low-contrast ghost borders:

- **Tiers of Matte Depth**:
  - **Level 0 (Base Canvas)**: `#0E1116` — Flat, non-interactive foundation.
  - **Level 1 (Card/Section Surface)**: `#161B22` with a 1px border of `rgba(240, 246, 252, 0.06)`. No drop shadow.
  - **Level 2 (Interactive Modules & Nested Items)**: `#21262D` with subtle edge highlights (`rgba(240, 246, 252, 0.1)`).
  - **Level 3 (Floating Action & Notch Calibration Hub)**: `#30363D` with an ultra-diffused atmospheric glow: `0 12px 32px rgba(0, 245, 160, 0.08)`.

- **Active State Illumination**: Rather than conventional drop shadows, active gesture targets emit a concentrated localized mint blur (`rgba(0, 245, 160, 0.25)` blur 12px) to simulate hardware feedback on dark glass.

## Shapes

The interface adopts modern Android curvature conventions (ranging from 16px to 24px) reflecting both phone chassis perimeters and front camera cutout geometries:

- **Container Roundedness (`rounded-lg` - 16px)**: Applied to all standard configuration cards, permission blocks, and action panels.
- **Primary Cards & Floating Sheets (`rounded-xl` - 24px)**: Applied to calibration previews, interactive punch-hole targeting zones, and bottom navigation sheets.
- **Pill Forms (`rounded-full`)**: Dedicated strictly to gesture chips, hardware mode tags, and toggle switches to maintain immediate semiotic distinction from rectangular structural cards.

## Components

### 1. Buttons & Triggers
- **Primary Action**: Filled pill with `#00F5A0` background, `#0E1116` heavy bold typography. Haptic feedback on tap with immediate 98% scale-down micro-interaction.
- **Secondary Action**: Background `#21262D`, 1px border `rgba(240, 246, 252, 0.08)`, text `#F0F6FC`. On pressed: tint shifts to `#30363D`.
- **Destructive/Reset**: Ghost button with `#EF4444` label and red tinted surface on press (`rgba(239, 68, 68, 0.12)`).

### 2. Gesture Mapping Cards
- Modular 16px rounded surfaces containing:
  - Left: Vector icon representing gesture (e.g., tap, double tap, hold, swipe ring).
  - Center: Title (`label-lg`) and mapped action description (`body-sm` in `#8B949E`).
  - Right: Mint state pill or chevron indicator.
- When an active trigger event occurs around the camera cutout, the corresponding card flashes a subtle 1px border highlight of `#00F5A0`.

### 3. Punch-Hole Calibration Radar
- A visual interactive component replicating the physical camera cutout position (X/Y coordinates, radius slider, sensitivity zone).
- Rendered on a pure black grid with `#00F5A0` animated vector rings and drag handles with pill tags displaying exact pixel dimensions.

### 4. Switch Toggles & Radio Modules
- **Switch**: Custom 28px height pill. Inactive: `#21262D` track with `#8B949E` thumb. Active: `#10B981` track with `#0E1116` thumb.
- **Radio Row**: Inset surface item with circular selector. Selected state features dual concentric rings in `#00F5A0`.

### 5. Chips & Badges
- Compact 24px height pills.
- Active system chips (e.g., "ACCESSIBILITY ACTIVE", "BATTERY INDICATOR RING") use `#161B22` background with `#00F5A0` text and 1px border in `rgba(0, 245, 160, 0.3)`.

### 6. Value Sliders (Sensitivity, Radius, Vibration Strength)
- Continuous matte track (`#21262D`, 6px height, rounded) filled with `#00F5A0`.
- Circular thumb (20px) in pure `#F0F6FC` with an outer ring in `#10B981` that expands on drag.