---
name: Technical Precision Android Utility
colors:
  surface: '#111317'
  surface-dim: '#111317'
  surface-bright: '#37393d'
  surface-container-lowest: '#0c0e11'
  surface-container-low: '#1a1c1f'
  surface-container: '#1e2023'
  surface-container-high: '#282a2d'
  surface-container-highest: '#333538'
  on-surface: '#e2e2e6'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#e2e2e6'
  inverse-on-surface: '#2f3034'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#c2c6d6'
  on-secondary: '#2b303c'
  secondary-container: '#444956'
  on-secondary-container: '#b4b8c7'
  tertiary: '#ffb77d'
  on-tertiary: '#4d2600'
  tertiary-container: '#f08921'
  on-tertiary-container: '#5a2e00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#dee2f2'
  secondary-fixed-dim: '#c2c6d6'
  on-secondary-fixed: '#161b27'
  on-secondary-fixed-variant: '#424753'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#111317'
  on-background: '#e2e2e6'
  surface-variant: '#333538'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

Ce système incarne l'ingénierie système bas niveau et l'utilitaire chirurgical pour Android natif. Conçu pour le remappage gestuel autour du poinçon de caméra frontale, il adopte une posture d'outil matériel : silencieux, ultra-réactif, sans fioriture décorative.

L'esthétique rejette explicitement les artifices graphiques génériques : aucun dégradé violet/cyan, aucun effet de flou ou glassmorphism, aucun glow diffus, aucune surface flottante néo-brutaliste ou pseudo-organique. L'interface s'inspire directement des consoles de diagnostic AOSP, de l'outillage industriel d'inspection optique et du design de composants natifs de précision. L'utilisateur doit ressentir le contrôle absolu d'un instrument calibré au micromètre.

## Colors

La palette repose sur l'optimisation OLED et le contraste structurel strict :

- **Fond absolu (`neutral_color_hex`)** : `#0d0f12` — Noir technique profond évitant les noirs purs délavés tout en éteignant la majorité des pixels d'écran.
- **Surfaces containers** :
  - Surface Level 1 : `#16191f` (cartes, listes d'ancrage, conteneurs d'écouteurs d'événements).
  - Surface Level 2 : `#1e222a` (états interactifs, badges techniques, zones de configuration de zone tactile).
- **Lignes structurelles** : `#2a2f3b` — Bordures nettes de 1px séparant physiquement les éléments et les jauges.
- **Accents de statut matériel** :
  - **Actif / Normal (`primary_color_hex`)** : `#10b981` (avec repli `#059669` pour les états pressés) pour signaler l'écoute active des capteurs, la validité des coordonnées et les déclencheurs calibrés.
  - **Avertissement (`tertiary_color_hex`)** : `#d97706` pour les conflits de gestes ou les autorisations d'accessibilité restreintes.
  - **Erreur critique** : `#dc2626` pour les dépassements de seuil matériel, interruptions du service d'arrière-plan ou zones mortes.
- **Typographie & Éléments de premier plan** :
  - Primaire : `#f1f5f9` (haute lisibilité sur fond sombre).
  - Secondaire / Métadonnées : `#94a3b8` (étiquettes, offsets X/Y, unités ms/px).
  - Inactif / Muet : `#475569`.

## Typography

La typographie est divisée de manière stricte par fonction :
- **Titres (`Space Grotesk`)** : Géométrique et dense, utilisée pour les en-têtes d'écrans, de sections logiques et les noms de capteurs.
- **Corps de texte (`IBM Plex Sans`)** : Lisibilité industrielle neutre, sans fioritures humanistes excessives, optimisée pour le rendu d'instructions courtes et de paramètres système.
- **Données matérielles & télémétrie (`JetBrains Mono`)** : Chiffres tabulaires, coordonnées spatiales du poinçon (r, θ, x, y), millisecondes de debounce, hexadécimaux et statuts des listeners natifs. Tous les nombres dynamiques doivent être rendus en JetBrains Mono pour éviter les décalages de mise en page lors des rafraîchissements haute fréquence.

## Layout & Spacing

L'architecture d'écran adopte une ergonomie "One-Hand Reach" inspirée de Material You et d'AOSP :
- **Top Bar / Sensor Area** : Zone d'affichage et de prévisualisation du poinçon (haut d'écran réservé aux indicateurs visuels non interactifs et à la simulation d'overlay).
- **Action & Control Zone** : Regroupement systématique des commandes de déclenchement, sliders et bascules dans la moitié inférieure de l'écran (accessibilité au pouce).
- **Grille & Alignement** : Système de conteneurs empilés sur une colonne unique fluide, scindée en blocs horizontaux de métriques. Les marges extérieures sont réduites à 16px (`1rem`) pour maximiser la densité informative sur les formats compacts et étroits (écrans 20:9 et 21:9).
- **Densité** : Espacements condensés (`space-sm` et `space-md` prédominants) pour maintenir un maximum de télémétrie visible sans nécessiter de défilement excessif.

## Elevation & Depth

Le design system proscrit entièrement les ombres portées et le pseudo-relief skeuomorphe :
- **Hiérarchie par étagement de tons** : Le plan de masse repose sur `#0d0f12`. Les zones groupées montent à `#16191f`. Les éléments ciblés ou actifs occupent `#1e222a`.
- **Contours de séparation microscopiques (Ghost Borders)** : Tous les containers, panneaux d'entrée et segments sont délimités par une bordure pleine de 1px `#2a2f3b`. Aucune ombre diffuse n'est appliquée.
- **Indication de focus matériel** : Lorsqu'un composant est actif ou écoute un geste, la bordure commute instantanément en `#10b981` (1px à 1.5px solide), sans halo ni flou.
- **Absence de transparence décorative** : Tout panneau est 100% opaque. L'illusion de profondeur découle exclusivement de la rigueur de superposition mécanique des surfaces.

## Shapes

Le langage de forme est compact et maîtrisé (`roundedness: 1`) :
- Rayon de base de `4px` (`0.25rem`) pour les badges, inputs, déclencheurs et segments techniques, évoquant des connecteurs et puces physiques.
- Rayon de `8px` (`0.5rem`) pour les cartes principales et les conteneurs de réglages.
- Aucune forme pilule intégrale n'est utilisée, à l'exception stricte de l'indicateur visuel du poinçon d'écran (pour correspondre au contour physique exact de la découpe matérielle de l'appareil).

## Components

### Boutons & Déclencheurs
- **Action Principale (Calibrer / Sauvegarder)** : Fond `#10b981`, texte `#0d0f12` en `JetBrains Mono` bold, hauteur 40px, rayon 4px. État pressé : `#059669`.
- **Action Secondaire (Écoute / Test)** : Fond `#1e222a`, bordure 1px `#2a2f3b`, texte `#f1f5f9`.
- **Action Critique (Réinitialiser matrice)** : Fond transparent, bordure 1px `#dc2626`, texte `#dc2626`.

### Cartes de Déclenchement Gestuel (Gesture Rows)
- Surfaces plates `#16191f` entourées d'une bordure 1px `#2a2f3b`.
- Disposition en 3 segments horizontaux : icône/symbole d'action vectorielle monochrome, label textuel du geste avec timing en millisecondes (`label-md`), et switch matériel Android.

### Sélecteurs & Contrôleurs Numériques (Sliders de précision)
- Piste fine de 2px en `#2a2f3b`.
- Progression en `#10b981`.
- Curseur carré de 12x12px avec rayon 2px, sans halo.
- Affichage numérique continu de l'offset (ex. `OFFSET_X: +04.2mm`) en `JetBrains Mono` directement aligné au-dessus du rail.

### Badges de Statut Matériel (Chips)
- Hauteur fixe 20px, padding horizontal 6px.
- Fond `#16191f`, bordure 1px dédiée au statut (`#10b981` pour `ONLINE`, `#d97706` pour `ACCESSIBILITY_UNBOUND`, `#dc2626` pour `HARDWARE_BLOCK`).
- Typographie `label-sm` en majuscules strictes. Point indicateur solide de 4px sans pulsation.

### Champs d'Entrée & Détection
- Fond `#0d0f12`, encadrement 1px `#2a2f3b`. Focus net avec passage immédiat à `#10b981`. Texte en police monospacée.